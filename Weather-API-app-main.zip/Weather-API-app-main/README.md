# weather-API-app

this is a small project to show how API works and how to handle them using async and await function.
After a break of month or so (due to exam) I thought it would be better if i do some practice on API.


# working:

  vanilla JS is used to handle the API req ans response
  simple yet reliable ASYNC and AWAIT function was used fetch the API data
  accept the data as json and segregate it according to our need
  and that's it , its just simple example of how to use API
  
  CSS/IMG:
    according to the api reerted data, we use the appropiate icons and image to show the weather description,
    we also used div(container) approach for this UI which was quite simple and easy to implement.
    
  JS:
    we use basic querySelector and Evenlistener function to initiate the weather forecasting process.
    A weather object was used in which we dumped our API data and dynamically assign those value to their proper places in our html tags.
    
    
  
  
# screenshots:

  (if user permits geolocation prompt) <br>
  <img width="271" alt="image" src="https://user-images.githubusercontent.com/76240365/171340449-e765daa0-f878-46e5-a47b-8f24e8539a5e.png">
  
  (if user denies the permission) <br>
  <img width="254" alt="image" src="https://user-images.githubusercontent.com/76240365/171340515-0f89de9c-b13e-46d4-a250-3cbe3700cd81.png">

